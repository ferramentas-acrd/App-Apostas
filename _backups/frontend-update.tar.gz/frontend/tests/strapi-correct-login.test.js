import { test, expect } from '@playwright/test';

test('Login com credenciais corretas - Apps de Apostas', async ({ page }) => {
  console.log('🧪 Fazendo login com credenciais corretas...');
  
  // Navegar para o admin do Strapi
  console.log('📍 Navegando para http://localhost:1338/admin');
  await page.goto('http://localhost:1338/admin');
  
  // Aguardar a página carregar
  await page.waitForTimeout(3000);
  
  // Screenshot inicial
  await page.screenshot({ 
    path: 'tests/screenshots/strapi-correct-initial.png',
    fullPage: true 
  });
  
  console.log('📝 Preenchendo credenciais corretas...');
  console.log('   Email: caio.bessa@acroud.media');
  console.log('   Senha: byMqat-hibdeh-9rycxy');
  
  // Preencher credenciais corretas
  await page.fill('input[name="email"]', 'caio.bessa@acroud.media');
  await page.fill('input[name="password"]', 'byMqat-hibdeh-9rycxy');
  
  // Screenshot antes do login
  await page.screenshot({ 
    path: 'tests/screenshots/strapi-correct-before-login.png',
    fullPage: true 
  });
  
  console.log('🔘 Clicando no botão de login...');
  await page.click('button[type="submit"]');
  
  // Aguardar navegação
  await page.waitForTimeout(10000); // Mais tempo para garantir
  
  // Verificar resultado
  const finalUrl = page.url();
  console.log(`🔗 URL final: ${finalUrl}`);
  
  // Screenshot final
  await page.screenshot({ 
    path: 'tests/screenshots/strapi-correct-final.png',
    fullPage: true 
  });
  
  // Verificar se o login foi bem-sucedido
  if (finalUrl.includes('/admin') && !finalUrl.includes('/login') && !finalUrl.includes('/auth')) {
    console.log('🎉 LOGIN BEM-SUCEDIDO! Chegamos ao dashboard do Strapi!');
    
    // Verificar título da página
    const title = await page.title();
    console.log(`📄 Título da página: ${title}`);
    
    // Procurar elementos do dashboard
    const welcomeElement = await page.locator('h1, h2, h3').first().textContent();
    console.log(`👋 Elemento de boas-vindas: ${welcomeElement}`);
    
    // Verificar navegação lateral
    const navigationLinks = await page.locator('nav a, [role="navigation"] a').count();
    console.log(`📊 Links de navegação encontrados: ${navigationLinks}`);
    
    // Verificar se há content types
    const contentManager = await page.locator('text=Content Manager, text=Content-Type Builder').count();
    console.log(`📋 Elementos de gerenciamento de conteúdo: ${contentManager}`);
    
    console.log('✅ TESTE BEM-SUCEDIDO - O admin do Strapi está funcionando perfeitamente!');
    
  } else {
    console.log('❌ Login ainda falhou');
    
    // Verificar se há mensagem de erro
    const errorMessages = await page.locator('.error, [role="alert"], .alert-danger, text=Invalid').count();
    if (errorMessages > 0) {
      const errorText = await page.locator('.error, [role="alert"], .alert-danger, text=Invalid').first().textContent();
      console.log(`❌ Mensagem de erro: ${errorText}`);
    }
  }
  
  console.log('🏁 Teste concluído!');
});