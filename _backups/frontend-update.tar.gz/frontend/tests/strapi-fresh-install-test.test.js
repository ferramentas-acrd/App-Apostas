import { test, expect } from '@playwright/test';

test('TESTE NOVA INSTALAÇÃO - Strapi Limpo', async ({ page }) => {
  console.log('🎯 TESTANDO NOVA INSTALAÇÃO LIMPA DO STRAPI');
  console.log('===========================================');
  console.log('');
  
  // Navegar para o admin da nova instalação
  console.log('📍 Navegando para http://localhost:1338/admin');
  await page.goto('http://localhost:1338/admin');
  await page.waitForTimeout(5000);
  
  const url = page.url();
  console.log(`🔗 URL atual: ${url}`);
  
  // Screenshot inicial
  await page.screenshot({ 
    path: 'tests/screenshots/fresh-install-initial.png',
    fullPage: true 
  });
  
  // Verificar se estamos no dashboard ou na tela de setup
  if (url.includes('/admin') && !url.includes('/login') && !url.includes('/auth') && !url.includes('/register')) {
    console.log('');
    console.log('🎉🎉🎉 SUCESSO TOTAL! 🎉🎉🎉');
    console.log('✅ Dashboard acessível imediatamente!');
    console.log('✅ Nova instalação funciona perfeitamente!');
    console.log('✅ Problema de login RESOLVIDO!');
    console.log('');
    
    // Aguardar dashboard carregar
    await page.waitForTimeout(3000);
    
    const title = await page.title();
    console.log(`📄 Título da página: ${title}`);
    
    // Verificar elementos do dashboard
    const contentManager = await page.locator('text=Content Manager, [href*="content-manager"]').count();
    const contentTypeBuilder = await page.locator('text=Content-Type Builder, [href*="content-type-builder"]').count();
    
    console.log(`📊 Elementos do dashboard:`);
    console.log(`   📋 Content Manager: ${contentManager > 0 ? 'ENCONTRADO' : 'NÃO ENCONTRADO'}`);
    console.log(`   🔧 Content-Type Builder: ${contentTypeBuilder > 0 ? 'ENCONTRADO' : 'NÃO ENCONTRADO'}`);
    
    console.log('');
    console.log('🏆 CMS STRAPI 100% FUNCIONAL!');
    console.log('📋 URL DO DASHBOARD: http://localhost:1338/admin');
    
  } else if (url.includes('/register')) {
    console.log('✅ Tela de registro detectada - criando primeiro usuário');
    
    // Preencher dados do primeiro admin
    await page.fill('input[name="firstname"]', 'Admin');
    await page.fill('input[name="lastname"]', 'Apps de Apostas');
    await page.fill('input[name="email"]', 'admin@appdeapostas.com.br');
    await page.fill('input[name="password"]', 'Admin123456!');
    
    const hasConfirmPassword = await page.locator('input[name="confirmPassword"]').count();
    if (hasConfirmPassword > 0) {
      await page.fill('input[name="confirmPassword"]', 'Admin123456!');
    }
    
    console.log('📝 Criando usuário admin...');
    await page.click('button[type="submit"]');
    await page.waitForTimeout(15000);
    
    const afterRegisterUrl = page.url();
    console.log(`🔗 URL após registro: ${afterRegisterUrl}`);
    
    if (!afterRegisterUrl.includes('/login') && !afterRegisterUrl.includes('/auth') && !afterRegisterUrl.includes('/register')) {
      console.log('');
      console.log('🎉 USUÁRIO CRIADO E LOGIN AUTOMÁTICO FUNCIONOU!');
      console.log('✅ Dashboard acessível!');
      console.log('📋 Credenciais: admin@appdeapostas.com.br / Admin123456!');
    }
    
  } else if (url.includes('/login')) {
    console.log('⚠️ Tela de login - tentando credenciais padrão');
    
    await page.fill('input[name="email"]', 'admin@appdeapostas.com.br');
    await page.fill('input[name="password"]', 'Admin123456!');
    await page.click('button[type="submit"]');
    await page.waitForTimeout(10000);
    
    const loginResult = page.url();
    if (!loginResult.includes('/login')) {
      console.log('✅ Login bem-sucedido!');
    } else {
      console.log('❌ Login falhou');
    }
  }
  
  // Screenshot final
  await page.screenshot({ 
    path: 'tests/screenshots/fresh-install-final.png',
    fullPage: true 
  });
  
  const finalUrl = page.url();
  console.log('');
  console.log(`🏁 URL FINAL: ${finalUrl}`);
  
  if (!finalUrl.includes('/login') && !finalUrl.includes('/auth') && !finalUrl.includes('/register')) {
    console.log('✅ TESTE BEM-SUCEDIDO - DASHBOARD ACESSÍVEL!');
  } else {
    console.log('❌ Ainda há problemas com o dashboard');
  }
  
  console.log('');
  console.log('🏁 Teste da nova instalação concluído!');
});