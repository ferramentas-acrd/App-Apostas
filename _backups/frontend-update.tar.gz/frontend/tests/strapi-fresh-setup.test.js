import { test, expect } from '@playwright/test';

test('SETUP COMPLETO - Criar primeiro admin Apps de Apostas', async ({ page }) => {
  console.log('🎯 SETUP COMPLETO DO ADMIN STRAPI - APPS DE APOSTAS');
  console.log('');
  
  // Navegar para o admin
  console.log('📍 Navegando para http://localhost:1338/admin');
  await page.goto('http://localhost:1338/admin');
  
  // Aguardar página carregar
  await page.waitForTimeout(5000);
  
  // Screenshot inicial
  await page.screenshot({ 
    path: 'tests/screenshots/fresh-setup-initial.png',
    fullPage: true 
  });
  
  const currentUrl = page.url();
  console.log(`🔗 URL inicial: ${currentUrl}`);
  
  // Verificar se é tela de primeiro usuário
  const hasFirstname = await page.locator('input[name="firstname"]').count();
  const hasLastname = await page.locator('input[name="lastname"]').count();
  const hasEmail = await page.locator('input[name="email"]').count();
  const hasPassword = await page.locator('input[name="password"]').count();
  
  console.log(`📝 Campos encontrados - Nome: ${hasFirstname}, Sobrenome: ${hasLastname}, Email: ${hasEmail}, Senha: ${hasPassword}`);
  
  if (hasFirstname > 0 && hasLastname > 0) {
    console.log('✅ TELA DE CRIAÇÃO DO PRIMEIRO USUÁRIO DETECTADA!');
    console.log('');
    
    // Preencher dados do primeiro admin
    console.log('📝 Criando primeiro administrador...');
    console.log('   👤 Nome: Admin Apps');
    console.log('   👤 Sobrenome: de Apostas');
    console.log('   📧 Email: admin@appdeapostas.com.br');
    console.log('   🔐 Senha: AppsDeApostas2024!');
    
    await page.fill('input[name="firstname"]', 'Admin Apps');
    await page.fill('input[name="lastname"]', 'de Apostas');
    await page.fill('input[name="email"]', 'admin@appdeapostas.com.br');
    await page.fill('input[name="password"]', 'AppsDeApostas2024!');
    
    // Verificar se há confirmação de senha
    const hasConfirmPassword = await page.locator('input[name="confirmPassword"], input[name="password_confirmation"]').count();
    if (hasConfirmPassword > 0) {
      await page.fill('input[name="confirmPassword"], input[name="password_confirmation"]', 'AppsDeApostas2024!');
      console.log('   🔐 Confirmação de senha preenchida');
    }
    
    // Screenshot antes de criar
    await page.screenshot({ 
      path: 'tests/screenshots/fresh-setup-filled.png',
      fullPage: true 
    });
    
    console.log('');
    console.log('🔘 Criando primeiro administrador...');
    await page.click('button[type="submit"]');
    
    // Aguardar criação (mais tempo)
    console.log('⏳ Aguardando criação do usuário (20 segundos)...');
    await page.waitForTimeout(20000);
    
    const finalUrl = page.url();
    console.log(`🔗 URL após criação: ${finalUrl}`);
    
    // Screenshot final
    await page.screenshot({ 
      path: 'tests/screenshots/fresh-setup-final.png',
      fullPage: true 
    });
    
    // Verificar resultado
    if (finalUrl.includes('/admin') && !finalUrl.includes('/login') && !finalUrl.includes('/auth') && !finalUrl.includes('/register')) {
      console.log('');
      console.log('🎉🎉🎉 SUCESSO TOTAL! 🎉🎉🎉');
      console.log('✅ Primeiro administrador criado com sucesso!');
      console.log('✅ Login automático realizado!');
      console.log('✅ Dashboard do Strapi acessível!');
      console.log('✅ Loop infinito de login RESOLVIDO!');
      console.log('');
      
      // Verificar elementos do dashboard
      const title = await page.title();
      console.log(`📄 Título da página: ${title}`);
      
      // Aguardar elementos carregarem
      await page.waitForTimeout(3000);
      
      // Tentar encontrar elementos específicos do Strapi
      const welcomeText = await page.locator('h1, h2, h3').first().textContent();
      console.log(`👋 Texto de boas-vindas: ${welcomeText}`);
      
      console.log('');
      console.log('🏆 ADMIN DO STRAPI 100% FUNCIONAL!');
      console.log('📋 Credenciais para uso:');
      console.log('   📧 Email: admin@appdeapostas.com.br');
      console.log('   🔐 Senha: AppsDeApostas2024!');
      
    } else {
      console.log('❌ Ainda há problemas com o setup');
      console.log(`📍 URL final: ${finalUrl}`);
    }
    
  } else if (hasEmail > 0 && hasPassword > 0) {
    console.log('⚠️  Tela de login detectada - usuário pode já existir');
    
    // Tentar fazer login com credenciais que você forneceu
    console.log('🔄 Tentando login com credenciais existentes...');
    await page.fill('input[name="email"]', 'caio.bessa@acroud.media');
    await page.fill('input[name="password"]', 'byMqat-hibdeh-9rycxy');
    await page.click('button[type="submit"]');
    
    await page.waitForTimeout(10000);
    
    const loginUrl = page.url();
    console.log(`🔗 URL após tentativa de login: ${loginUrl}`);
    
    await page.screenshot({ 
      path: 'tests/screenshots/fresh-setup-login-attempt.png',
      fullPage: true 
    });
  }
  
  console.log('');
  console.log('🏁 Setup concluído!');
});