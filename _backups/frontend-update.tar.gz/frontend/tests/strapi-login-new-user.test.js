import { test, expect } from '@playwright/test';

test('LOGIN COM NOVO USUÁRIO - Apps de Apostas', async ({ page }) => {
  console.log('🎯 TESTANDO LOGIN COM USUÁRIO RECÉM-CRIADO');
  console.log('');
  
  // Navegar para admin
  console.log('📍 Navegando para http://localhost:1338/admin');
  await page.goto('http://localhost:1338/admin');
  
  await page.waitForTimeout(5000);
  
  const currentUrl = page.url();
  console.log(`🔗 URL inicial: ${currentUrl}`);
  
  // Screenshot inicial
  await page.screenshot({ 
    path: 'tests/screenshots/new-user-login-initial.png',
    fullPage: true 
  });
  
  // Verificar se está na tela de login
  if (currentUrl.includes('/login')) {
    console.log('✅ Tela de login detectada');
    console.log('');
    console.log('📝 Tentando login com credenciais do usuário recém-criado:');
    console.log('   📧 Email: admin@appdeapostas.com.br');
    console.log('   🔐 Senha: AppsDeApostas2024!');
    
    // Preencher credenciais do usuário que acabamos de criar
    await page.fill('input[name="email"]', 'admin@appdeapostas.com.br');
    await page.fill('input[name="password"]', 'AppsDeApostas2024!');
    
    // Screenshot antes do login
    await page.screenshot({ 
      path: 'tests/screenshots/new-user-login-filled.png',
      fullPage: true 
    });
    
    console.log('🔘 Fazendo login...');
    await page.click('button[type="submit"]');
    
    // Aguardar resposta
    console.log('⏳ Aguardando resposta do servidor...');
    await page.waitForTimeout(15000);
    
    const finalUrl = page.url();
    console.log(`🔗 URL final: ${finalUrl}`);
    
    // Screenshot final
    await page.screenshot({ 
      path: 'tests/screenshots/new-user-login-final.png',
      fullPage: true 
    });
    
    // Verificar resultado
    if (finalUrl.includes('/admin') && !finalUrl.includes('/login') && !finalUrl.includes('/auth')) {
      console.log('');
      console.log('🎉🎉🎉 FINALMENTE! LOGIN BEM-SUCEDIDO! 🎉🎉🎉');
      console.log('✅ Usuário criado e logado com sucesso!');
      console.log('✅ Dashboard do Strapi acessível!');
      console.log('✅ LOOP INFINITO RESOLVIDO DEFINITIVAMENTE!');
      console.log('');
      
      // Aguardar dashboard carregar
      await page.waitForTimeout(3000);
      
      const title = await page.title();
      console.log(`📄 Título: ${title}`);
      
      // Procurar pelo texto de boas-vindas
      const welcomeElement = await page.locator('h1, h2, h3, [data-testid="main-nav"]').first();
      if (await welcomeElement.count() > 0) {
        const welcomeText = await welcomeElement.textContent();
        console.log(`👋 Dashboard: ${welcomeText}`);
      }
      
      console.log('');
      console.log('🏆 STRAPI ADMIN 100% FUNCIONAL!');
      console.log('');
      console.log('📋 CREDENCIAIS FINAIS:');
      console.log('   📧 Email: admin@appdeapostas.com.br');
      console.log('   🔐 Senha: AppsDeApostas2024!');
      console.log('   🔗 URL: http://localhost:1338/admin');
      
    } else {
      console.log('❌ Login ainda não funcionou');
      
      // Verificar se há erro visível
      const errorVisible = await page.locator('text=Invalid, text=Error, .error, [role="alert"]').count();
      if (errorVisible > 0) {
        const errorText = await page.locator('text=Invalid, text=Error, .error, [role="alert"]').first().textContent();
        console.log(`❌ Erro detectado: ${errorText}`);
      }
    }
    
  } else {
    console.log('❓ Estado inesperado');
    console.log(`📍 URL: ${currentUrl}`);
  }
  
  console.log('');
  console.log('🏁 Teste concluído!');
});