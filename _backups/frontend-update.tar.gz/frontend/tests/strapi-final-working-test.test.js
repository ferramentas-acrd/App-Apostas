import { test, expect } from '@playwright/test';

test('TESTE FINAL FUNCIONAL - Credenciais Originais', async ({ page }) => {
  console.log('🎯 TESTE FINAL COM CREDENCIAIS ORIGINAIS');
  console.log('======================================');
  console.log('');
  console.log('📋 USANDO CREDENCIAIS DO BANCO:');
  console.log('   📧 Email: caio.bessa@acroud.media');
  console.log('   🔐 Senha: byMqat-hibdeh-9rycxy');
  console.log('');
  
  // Navegar
  await page.goto('http://localhost:1338/admin');
  await page.waitForTimeout(5000);
  
  console.log(`🔗 URL inicial: ${page.url()}`);
  
  // Screenshot inicial
  await page.screenshot({ 
    path: 'tests/screenshots/final-working-initial.png',
    fullPage: true 
  });
  
  // Preencher credenciais originais
  console.log('📝 Preenchendo credenciais originais...');
  await page.fill('input[name="email"]', 'caio.bessa@acroud.media');
  await page.fill('input[name="password"]', 'byMqat-hibdeh-9rycxy');
  
  // Screenshot antes do login
  await page.screenshot({ 
    path: 'tests/screenshots/final-working-login.png',
    fullPage: true 
  });
  
  console.log('🔘 Fazendo login...');
  await page.click('button[type="submit"]');
  
  // Aguardar resposta
  console.log('⏳ Aguardando resultado...');
  await page.waitForTimeout(15000);
  
  const resultUrl = page.url();
  console.log(`🔗 URL resultado: ${resultUrl}`);
  
  // Screenshot final
  await page.screenshot({ 
    path: 'tests/screenshots/final-working-result.png',
    fullPage: true 
  });
  
  // Verificar resultado FINAL
  if (!resultUrl.includes('/login') && !resultUrl.includes('/auth') && !resultUrl.includes('/register')) {
    console.log('');
    console.log('🎉🎉🎉 FINALMENTE! SUCESSO ABSOLUTO! 🎉🎉🎉');
    console.log('✅ LOGIN FUNCIONOU PERFEITAMENTE!');
    console.log('✅ DASHBOARD DO STRAPI ACESSÍVEL!');
    console.log('✅ NOVA INSTALAÇÃO RESOLVEU O PROBLEMA!');
    console.log('✅ CMS 100% OPERACIONAL!');
    console.log('');
    
    // Verificar elementos do dashboard
    await page.waitForTimeout(3000);
    
    const title = await page.title();
    console.log(`📄 Título: ${title}`);
    
    const contentManager = await page.locator('text=Content Manager, [href*="content-manager"]').count();
    console.log(`📊 Content Manager: ${contentManager > 0 ? 'ENCONTRADO ✅' : 'NÃO ENCONTRADO ❌'}`);
    
    console.log('');
    console.log('🏆 PROJETO APPS DE APOSTAS - 100% FUNCIONAL!');
    console.log('📋 CREDENCIAIS FUNCIONAIS:');
    console.log('   📧 Email: caio.bessa@acroud.media');
    console.log('   🔐 Senha: byMqat-hibdeh-9rycxy');
    console.log('   🔗 URL: http://localhost:1338/admin');
    console.log('');
    console.log('📱 FRONTEND: http://localhost:4000');
    console.log('🗄️ CMS: http://localhost:1338/admin');
    
  } else {
    console.log('❌ Login ainda não funcionou com credenciais originais');
    
    // Tentar outras credenciais
    console.log('🔄 Tentando outras credenciais...');
    
    const otherCreds = [
      { email: 'admin@appdeapostas.com.br', password: 'Admin123456!' },
      { email: 'admin@appdeapostas.com.br', password: 'AppsDeApostas2024!' }
    ];
    
    for (const cred of otherCreds) {
      console.log(`🔄 Tentando: ${cred.email}`);
      
      await page.fill('input[name="email"]', cred.email);
      await page.fill('input[name="password"]', cred.password);
      await page.click('button[type="submit"]');
      await page.waitForTimeout(8000);
      
      const testUrl = page.url();
      if (!testUrl.includes('/login')) {
        console.log(`✅ SUCESSO com ${cred.email}!`);
        break;
      }
    }
  }
  
  console.log('');
  console.log('🏁 Teste final concluído!');
});