const { chromium } = require('@playwright/test');

(async () => {
  // Launch browser
  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  const page = await context.newPage();

  try {
    console.log('🔍 Testando site Melhor Palpite em produção...\n');
    
    // Navigate to the website
    await page.goto('http://54.91.137.79', { waitUntil: 'networkidle' });
    
    // Take screenshot
    await page.screenshot({ path: 'melhor-palpite-homepage.png', fullPage: true });
    console.log('✅ Screenshot salvo: melhor-palpite-homepage.png\n');

    // Check for new components
    console.log('📋 Verificando componentes do novo layout:\n');

    // Check Header
    const header = await page.locator('.mp-header').count();
    console.log(`Header Melhor Palpite: ${header > 0 ? '✅ Presente' : '❌ Não encontrado'}`);

    // Check promotional bar
    const promoBar = await page.locator('.mp-promo-bar').count();
    console.log(`Barra Promocional: ${promoBar > 0 ? '✅ Presente' : '❌ Não encontrado'}`);

    // Check Hero Section
    const hero = await page.locator('.mp-hero').count();
    console.log(`Hero Section: ${hero > 0 ? '✅ Presente' : '❌ Não encontrado'}`);

    // Check Betting Houses Section
    const bettingSection = await page.locator('.mp-betting-section').count();
    console.log(`Seção Casas de Apostas: ${bettingSection > 0 ? '✅ Presente' : '❌ Não encontrado'}`);

    // Check Live Betting
    const liveBetting = await page.locator('.mp-live-section').count();
    console.log(`Seção Apostas ao Vivo: ${liveBetting > 0 ? '✅ Presente' : '❌ Não encontrado'}`);

    // Check Footer
    const footer = await page.locator('.mp-footer').count();
    console.log(`Footer Melhor Palpite: ${footer > 0 ? '✅ Presente' : '❌ Não encontrado'}`);

    // Check Newsletter
    const newsletter = await page.locator('.mp-newsletter').count();
    console.log(`Newsletter Section: ${newsletter > 0 ? '✅ Presente' : '❌ Não encontrado'}`);

    // Check if old Corinthians components exist
    console.log('\n🔍 Verificando componentes antigos (Corinthians):\n');
    const oldHeader = await page.locator('.header, .site-header').count();
    console.log(`Header antigo: ${oldHeader > 0 ? '⚠️  Ainda presente' : '✅ Removido'}`);

    // Get page title
    const title = await page.title();
    console.log(`\n📝 Título da página: "${title}"`);

    // Check for CSS variables
    const cssVariables = await page.evaluate(() => {
      const styles = getComputedStyle(document.documentElement);
      return {
        primaryColor: styles.getPropertyValue('--mp-primary'),
        hasNewStyles: !!styles.getPropertyValue('--mp-primary')
      };
    });

    console.log(`\n🎨 Sistema de cores Melhor Palpite: ${cssVariables.hasNewStyles ? '✅ Aplicado' : '❌ Não encontrado'}`);
    if (cssVariables.primaryColor) {
      console.log(`   Cor primária: ${cssVariables.primaryColor}`);
    }

    // Check page content
    const pageContent = await page.content();
    const hasOldBranding = pageContent.includes('Corinthians') || pageContent.includes('corinthians');
    const hasNewBranding = pageContent.includes('Melhor Palpite') || pageContent.includes('melhor-palpite');
    
    console.log(`\n🏷️  Branding:`);
    console.log(`   Melhor Palpite: ${hasNewBranding ? '✅ Presente' : '❌ Não encontrado'}`);
    console.log(`   Corinthians: ${hasOldBranding ? '⚠️  Ainda presente' : '✅ Removido'}`);

  } catch (error) {
    console.error('❌ Erro durante o teste:', error.message);
  } finally {
    await browser.close();
    console.log('\n✅ Teste concluído!');
  }
})();