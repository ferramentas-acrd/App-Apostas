import { test, expect } from '@playwright/test';

test('Criar usuário no Admin Strapi - Apps de Apostas', async ({ page }) => {
  console.log('🧪 Testando criação de usuário admin...');
  
  // Navegar para o admin do Strapi
  console.log('📍 Navegando para http://localhost:1338/admin');
  await page.goto('http://localhost:1338/admin');
  
  // Aguardar a página carregar
  await page.waitForTimeout(3000);
  
  // Screenshot inicial
  await page.screenshot({ 
    path: 'tests/screenshots/strapi-initial.png',
    fullPage: true 
  });
  console.log('📸 Screenshot inicial salvo');
  
  // Verificar se estamos na tela de registro ou login
  const currentUrl = page.url();
  console.log(`🔗 URL atual: ${currentUrl}`);
  
  // Verificar elementos na página
  const hasEmailField = await page.locator('input[name="email"]').count();
  const hasPasswordField = await page.locator('input[name="password"]').count();
  const hasFirstnameField = await page.locator('input[name="firstname"]').count();
  
  console.log(`📝 Campos encontrados - Email: ${hasEmailField}, Password: ${hasPasswordField}, Firstname: ${hasFirstnameField}`);
  
  if (hasFirstnameField > 0) {
    // Estamos na tela de criação do primeiro usuário
    console.log('✅ Tela de criação do primeiro usuário detectada');
    
    await page.fill('input[name="firstname"]', 'Admin');
    await page.fill('input[name="lastname"]', 'Apps de Apostas');
    await page.fill('input[name="email"]', 'admin@appdeapostas.com.br');
    await page.fill('input[name="password"]', 'AppsDeApostas2024!');
    
    // Verificar se há campo de confirmação de senha
    const confirmPasswordField = await page.locator('input[name="confirmPassword"], input[name="password_confirmation"]').count();
    if (confirmPasswordField > 0) {
      await page.fill('input[name="confirmPassword"], input[name="password_confirmation"]', 'AppsDeApostas2024!');
      console.log('📝 Confirmação de senha preenchida');
    }
    
    // Screenshot antes de criar
    await page.screenshot({ 
      path: 'tests/screenshots/strapi-register-form.png',
      fullPage: true 
    });
    
    // Submeter formulário
    console.log('🔘 Criando usuário admin...');
    await page.click('button[type="submit"]');
    
    // Aguardar navegação
    await page.waitForTimeout(5000);
    
  } else if (hasEmailField > 0 && hasPasswordField > 0) {
    // Estamos na tela de login
    console.log('✅ Tela de login detectada - tentando fazer login...');
    
    await page.fill('input[name="email"]', 'admin@appdeapostas.com.br');
    await page.fill('input[name="password"]', 'AppsDeApostas2024!');
    
    // Screenshot antes de fazer login
    await page.screenshot({ 
      path: 'tests/screenshots/strapi-login-form.png',
      fullPage: true 
    });
    
    // Fazer login
    console.log('🔘 Fazendo login...');
    await page.click('button[type="submit"]');
    
    // Aguardar navegação
    await page.waitForTimeout(5000);
  }
  
  // Verificar resultado final
  const finalUrl = page.url();
  console.log(`🔗 URL final: ${finalUrl}`);
  
  // Screenshot final
  await page.screenshot({ 
    path: 'tests/screenshots/strapi-final-result.png',
    fullPage: true 
  });
  
  // Verificar se chegamos ao dashboard
  if (finalUrl.includes('/admin') && !finalUrl.includes('/login') && !finalUrl.includes('/register')) {
    console.log('🎉 SUCESSO! Acesso ao dashboard do Strapi realizado!');
    
    // Verificar elementos do dashboard
    const dashboardTitle = await page.title();
    console.log(`📄 Título da página: ${dashboardTitle}`);
    
    // Procurar por elementos típicos do dashboard
    const navigationElements = await page.locator('nav, [role="navigation"]').count();
    const mainContent = await page.locator('main, [role="main"]').count();
    
    console.log(`📊 Elementos do dashboard - Nav: ${navigationElements}, Main: ${mainContent}`);
    
  } else {
    console.log('❌ Ainda não conseguimos acessar o dashboard');
  }
  
  console.log('🏁 Teste concluído!');
});