import { test, expect } from '@playwright/test';

test('Teste do Admin Strapi - Apps de Apostas', async ({ page }) => {
  console.log('🧪 Iniciando teste do admin Strapi...');
  
  // Navegar para o admin do Strapi
  console.log('📍 Navegando para http://localhost:1338/admin');
  await page.goto('http://localhost:1338/admin');
  
  // Aguardar a página carregar
  await page.waitForTimeout(3000);
  
  // Verificar se a página carregou
  console.log('🔍 Verificando se a página do admin carregou...');
  
  // Tentar diferentes seletores que podem aparecer na página de admin
  const possibleSelectors = [
    'h1', 
    '[data-testid="login-form"]',
    'input[name="email"]',
    'input[name="password"]',
    '.welcome-title',
    '[role="main"]',
    'main'
  ];
  
  let foundElement = null;
  for (const selector of possibleSelectors) {
    try {
      await page.waitForSelector(selector, { timeout: 2000 });
      foundElement = selector;
      console.log(`✅ Encontrado elemento: ${selector}`);
      break;
    } catch (e) {
      console.log(`❌ Não encontrado: ${selector}`);
    }
  }
  
  // Screenshot para debug
  await page.screenshot({ 
    path: 'tests/screenshots/strapi-admin-debug.png',
    fullPage: true 
  });
  console.log('📸 Screenshot salvo em tests/screenshots/strapi-admin-debug.png');
  
  // Verificar o título da página
  const title = await page.title();
  console.log(`📄 Título da página: "${title}"`);
  
  // Verificar a URL atual
  const currentUrl = page.url();
  console.log(`🔗 URL atual: ${currentUrl}`);
  
  // Verificar se há elementos de formulário de login
  const emailInput = await page.locator('input[name="email"]').count();
  const passwordInput = await page.locator('input[name="password"]').count();
  
  if (emailInput > 0 && passwordInput > 0) {
    console.log('✅ Formulário de login encontrado - Primeira configuração necessária');
    
    // Tentar preencher o formulário de primeiro usuário
    await page.fill('input[name="email"]', 'admin@appdeapostas.com.br');
    await page.fill('input[name="password"]', 'AppDeApostas2024!');
    
    // Procurar campo de nome se existir
    const firstnameInput = await page.locator('input[name="firstname"]').count();
    if (firstnameInput > 0) {
      await page.fill('input[name="firstname"]', 'Admin');
      console.log('📝 Campo firstname preenchido');
    }
    
    const lastnameInput = await page.locator('input[name="lastname"]').count();
    if (lastnameInput > 0) {
      await page.fill('input[name="lastname"]', 'Apps de Apostas');
      console.log('📝 Campo lastname preenchido');
    }
    
    // Screenshot antes de submeter
    await page.screenshot({ 
      path: 'tests/screenshots/strapi-admin-form-filled.png',
      fullPage: true 
    });
    
    // Procurar e clicar no botão de submit
    const submitButton = page.locator('button[type="submit"]').first();
    const submitButtonCount = await submitButton.count();
    
    if (submitButtonCount > 0) {
      console.log('🔘 Clicando no botão de submit...');
      await submitButton.click();
      
      // Aguardar navegação ou resposta
      await page.waitForTimeout(5000);
      
      // Screenshot após submit
      await page.screenshot({ 
        path: 'tests/screenshots/strapi-admin-after-submit.png',
        fullPage: true 
      });
      
      console.log(`🔗 URL após submit: ${page.url()}`);
    }
    
  } else {
    console.log('❌ Formulário de login não encontrado');
  }
  
  // Aguardar um pouco mais para ver o resultado final
  await page.waitForTimeout(3000);
  
  // Screenshot final
  await page.screenshot({ 
    path: 'tests/screenshots/strapi-admin-final.png',
    fullPage: true 
  });
  
  console.log('🏁 Teste concluído!');
});