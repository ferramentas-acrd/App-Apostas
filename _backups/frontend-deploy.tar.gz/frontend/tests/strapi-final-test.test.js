import { test, expect } from '@playwright/test';

test('TESTE DEFINITIVO - Acesso ao Dashboard Strapi', async ({ page }) => {
  console.log('🎯 TESTE DEFINITIVO - APPS DE APOSTAS CMS');
  console.log('=====================================');
  console.log('');
  
  // Navegação
  console.log('📍 Navegando para http://localhost:1338/admin');
  await page.goto('http://localhost:1338/admin');
  await page.waitForTimeout(5000);
  
  const initialUrl = page.url();
  console.log(`🔗 URL inicial: ${initialUrl}`);
  
  // Screenshot inicial
  await page.screenshot({ 
    path: 'tests/screenshots/final-test-initial.png',
    fullPage: true 
  });
  
  // Verificar tipo de tela
  const hasFirstname = await page.locator('input[name="firstname"]').count();
  const hasEmail = await page.locator('input[name="email"]').count();
  
  console.log(`📝 Campos detectados - Nome: ${hasFirstname}, Email: ${hasEmail}`);
  
  if (hasFirstname > 0) {
    // Tela de criação do primeiro usuário
    console.log('');
    console.log('✅ TELA DE PRIMEIRO USUÁRIO DETECTADA');
    console.log('📝 Criando administrador...');
    console.log('');
    
    await page.fill('input[name="firstname"]', 'Admin');
    await page.fill('input[name="lastname"]', 'AppsDeApostas');
    await page.fill('input[name="email"]', 'admin@appdeapostas.com.br');
    await page.fill('input[name="password"]', 'Admin123456!');
    
    // Confirmar senha se existir
    const hasConfirmPassword = await page.locator('input[name="confirmPassword"]').count();
    if (hasConfirmPassword > 0) {
      await page.fill('input[name="confirmPassword"]', 'Admin123456!');
    }
    
    console.log('📋 CREDENCIAIS DEFINIDAS:');
    console.log('   📧 Email: admin@appdeapostas.com.br');
    console.log('   🔐 Senha: Admin123456!');
    console.log('');
    
    // Screenshot antes de criar
    await page.screenshot({ 
      path: 'tests/screenshots/final-test-creating.png',
      fullPage: true 
    });
    
    console.log('🔘 Criando administrador...');
    await page.click('button[type="submit"]');
    
    // Aguardar criação e redirecionamento
    console.log('⏳ Aguardando criação e login automático...');
    await page.waitForTimeout(20000);
    
    const afterCreateUrl = page.url();
    console.log(`🔗 URL após criação: ${afterCreateUrl}`);
    
    // Screenshot após criação
    await page.screenshot({ 
      path: 'tests/screenshots/final-test-after-create.png',
      fullPage: true 
    });
    
    // Verificar se chegou ao dashboard
    if (!afterCreateUrl.includes('/login') && !afterCreateUrl.includes('/auth') && !afterCreateUrl.includes('/register')) {
      console.log('');
      console.log('🎉🎉🎉 SUCESSO TOTAL! 🎉🎉🎉');
      console.log('✅ Usuário criado com sucesso!');
      console.log('✅ Login automático funcionou!');
      console.log('✅ Dashboard acessível!');
      console.log('');
      
      // Aguardar dashboard carregar completamente
      await page.waitForTimeout(5000);
      
      const title = await page.title();
      console.log(`📄 Título da página: ${title}`);
      
      // Procurar elementos característicos do dashboard Strapi
      const strapiElements = [
        'text=Welcome',
        'text=Content Manager',
        'text=Content-Type Builder',
        '[data-cy="main-nav"]',
        'nav',
        'main'
      ];
      
      let foundDashboard = false;
      for (const selector of strapiElements) {
        const count = await page.locator(selector).count();
        if (count > 0) {
          console.log(`✅ Elemento do dashboard encontrado: ${selector}`);
          foundDashboard = true;
          break;
        }
      }
      
      if (foundDashboard) {
        console.log('');
        console.log('🏆 DASHBOARD DO STRAPI TOTALMENTE FUNCIONAL!');
        console.log('🎯 MISSÃO CUMPRIDA - CMS 100% OPERACIONAL!');
        console.log('');
        console.log('📋 INFORMAÇÕES FINAIS:');
        console.log(`   🔗 URL: ${afterCreateUrl}`);
        console.log('   📧 Email: admin@appdeapostas.com.br');
        console.log('   🔐 Senha: Admin123456!');
      } else {
        console.log('⚠️ Dashboard carregou mas elementos não foram encontrados');
      }
      
    } else {
      console.log('❌ Ainda redirecionando para login');
    }
    
  } else if (hasEmail > 0) {
    // Tela de login
    console.log('');
    console.log('⚠️ TELA DE LOGIN DETECTADA - Tentando credenciais anteriores...');
    console.log('');
    
    // Tentar com credenciais que podem existir
    const credentials = [
      { email: 'admin@appdeapostas.com.br', password: 'Admin123456!' },
      { email: 'admin@appdeapostas.com.br', password: 'AppsDeApostas2024!' },
      { email: 'caio.bessa@acroud.media', password: 'byMqat-hibdeh-9rycxy' }
    ];
    
    for (const cred of credentials) {
      console.log(`🔄 Tentando: ${cred.email}`);
      
      await page.fill('input[name="email"]', cred.email);
      await page.fill('input[name="password"]', cred.password);
      await page.click('button[type="submit"]');
      await page.waitForTimeout(8000);
      
      const testUrl = page.url();
      if (!testUrl.includes('/login') && !testUrl.includes('/auth')) {
        console.log(`✅ SUCESSO com ${cred.email}!`);
        break;
      } else {
        console.log(`❌ Falhou com ${cred.email}`);
      }
    }
  }
  
  // Screenshot final
  await page.screenshot({ 
    path: 'tests/screenshots/final-test-result.png',
    fullPage: true 
  });
  
  const veryFinalUrl = page.url();
  console.log('');
  console.log(`🏁 URL FINAL: ${veryFinalUrl}`);
  
  if (!veryFinalUrl.includes('/login') && !veryFinalUrl.includes('/auth')) {
    console.log('🎉 TESTE FINAL BEM-SUCEDIDO!');
  } else {
    console.log('❌ Problema persistente com login');
  }
});