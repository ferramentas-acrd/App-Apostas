import { test, expect } from '@playwright/test';

test('Login no Admin Strapi - Apps de Apostas', async ({ page }) => {
  console.log('🧪 Iniciando login no admin Strapi...');
  
  // Navegar para o admin do Strapi
  console.log('📍 Navegando para http://localhost:1338/admin');
  await page.goto('http://localhost:1338/admin');
  
  // Aguardar a página carregar
  await page.waitForTimeout(3000);
  
  // Verificar se estamos na tela de login
  console.log('🔍 Verificando se estamos na tela de login...');
  
  try {
    await page.waitForSelector('input[name="email"]', { timeout: 5000 });
    console.log('✅ Tela de login encontrada');
    
    // Preencher credenciais
    console.log('📝 Preenchendo credenciais...');
    await page.fill('input[name="email"]', 'caio.bessa@acroud.media');
    await page.fill('input[name="password"]', 'byMqat-hibdeh-9rycxy');
    
    // Screenshot antes do login
    await page.screenshot({ 
      path: 'tests/screenshots/strapi-before-login.png',
      fullPage: true 
    });
    console.log('📸 Screenshot antes do login salvo');
    
    // Clicar no botão de login
    console.log('🔘 Clicando no botão de login...');
    await page.click('button[type="submit"]');
    
    // Aguardar navegação
    await page.waitForTimeout(5000);
    
    // Verificar se o login foi bem-sucedido
    const currentUrl = page.url();
    console.log(`🔗 URL após login: ${currentUrl}`);
    
    // Screenshot após login
    await page.screenshot({ 
      path: 'tests/screenshots/strapi-after-login.png',
      fullPage: true 
    });
    console.log('📸 Screenshot após login salvo');
    
    // Verificar se chegamos ao dashboard
    if (currentUrl.includes('/admin') && !currentUrl.includes('/login')) {
      console.log('✅ Login realizado com sucesso! Chegamos ao dashboard');
      
      // Tentar encontrar elementos do dashboard
      const dashboardElements = [
        '[data-testid="homepage"]',
        '.main-content',
        '[role="main"]',
        'h1',
        'nav'
      ];
      
      for (const selector of dashboardElements) {
        try {
          await page.waitForSelector(selector, { timeout: 2000 });
          console.log(`✅ Elemento do dashboard encontrado: ${selector}`);
          break;
        } catch (e) {
          console.log(`❌ Elemento não encontrado: ${selector}`);
        }
      }
      
      // Verificar se há menu de navegação
      const navigationLinks = await page.locator('nav a, [role="navigation"] a').count();
      console.log(`📊 Links de navegação encontrados: ${navigationLinks}`);
      
      // Verificar se há content types
      const contentTypeLinks = await page.locator('a[href*="content-manager"]').count();
      console.log(`📋 Links de content types encontrados: ${contentTypeLinks}`);
      
    } else {
      console.log('❌ Login falhou - ainda na tela de login');
      
      // Verificar se há mensagem de erro
      const errorMessage = await page.locator('.error, [role="alert"], .alert-danger').count();
      if (errorMessage > 0) {
        const errorText = await page.locator('.error, [role="alert"], .alert-danger').first().textContent();
        console.log(`❌ Mensagem de erro: ${errorText}`);
      }
    }
    
  } catch (error) {
    console.log(`❌ Erro durante o teste: ${error.message}`);
    
    // Screenshot de erro
    await page.screenshot({ 
      path: 'tests/screenshots/strapi-error.png',
      fullPage: true 
    });
  }
  
  // Screenshot final
  await page.screenshot({ 
    path: 'tests/screenshots/strapi-login-final.png',
    fullPage: true 
  });
  
  console.log('🏁 Teste de login concluído!');
});