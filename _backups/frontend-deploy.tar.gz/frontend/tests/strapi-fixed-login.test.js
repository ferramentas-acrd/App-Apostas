import { test, expect } from '@playwright/test';

test('Teste LOGIN CORRIGIDO - Apps de Apostas', async ({ page }) => {
  console.log('🎯 TESTANDO CORREÇÃO DO LOOP INFINITO DE LOGIN');
  console.log('');
  
  // Navegar para o admin do Strapi
  console.log('📍 Navegando para http://localhost:1338/admin');
  await page.goto('http://localhost:1338/admin');
  
  // Aguardar página carregar
  await page.waitForTimeout(5000);
  
  // Screenshot inicial
  await page.screenshot({ 
    path: 'tests/screenshots/fixed-login-initial.png',
    fullPage: true 
  });
  
  const currentUrl = page.url();
  console.log(`🔗 URL inicial: ${currentUrl}`);
  
  // Verificar se está na tela de login
  if (currentUrl.includes('/login') || currentUrl.includes('/auth')) {
    console.log('✅ Tela de login detectada');
    
    // Preencher credenciais corretas
    console.log('📝 Preenchendo credenciais corretas...');
    console.log('   📧 Email: caio.bessa@acroud.media');
    console.log('   🔐 Senha: byMqat-hibdeh-9rycxy');
    
    await page.fill('input[name="email"]', 'caio.bessa@acroud.media');
    await page.fill('input[name="password"]', 'byMqat-hibdeh-9rycxy');
    
    // Screenshot antes do login
    await page.screenshot({ 
      path: 'tests/screenshots/fixed-login-filled.png',
      fullPage: true 
    });
    
    console.log('🔘 Clicando no botão de login...');
    await page.click('button[type="submit"]');
    
    // Aguardar um pouco mais para garantir
    console.log('⏳ Aguardando navegação (15 segundos)...');
    await page.waitForTimeout(15000);
    
    const finalUrl = page.url();
    console.log(`🔗 URL final: ${finalUrl}`);
    
    // Screenshot final
    await page.screenshot({ 
      path: 'tests/screenshots/fixed-login-final.png',
      fullPage: true 
    });
    
    // Verificar se saiu do loop
    if (finalUrl.includes('/admin') && !finalUrl.includes('/login') && !finalUrl.includes('/auth')) {
      console.log('');
      console.log('🎉🎉🎉 SUCESSO! LOOP INFINITO CORRIGIDO! 🎉🎉🎉');
      console.log('✅ Login realizado com sucesso!');
      console.log('✅ Acesso ao dashboard do Strapi funcionando!');
      console.log('');
      
      // Verificar elementos do dashboard
      const title = await page.title();
      console.log(`📄 Título da página: ${title}`);
      
      // Aguardar elementos do dashboard carregarem
      await page.waitForTimeout(3000);
      
      // Verificar se há navegação
      const navElements = await page.locator('nav, [role="navigation"]').count();
      console.log(`🧭 Elementos de navegação: ${navElements}`);
      
      // Verificar se há conteúdo principal
      const mainElements = await page.locator('main, [role="main"]').count();
      console.log(`📋 Elementos principais: ${mainElements}`);
      
      // Tentar encontrar Content Manager
      const contentManager = await page.locator('text=Content Manager').count();
      console.log(`📊 Content Manager encontrado: ${contentManager > 0 ? 'SIM' : 'NÃO'}`);
      
      console.log('');
      console.log('🏆 TESTE BEM-SUCEDIDO! O ADMIN DO STRAPI ESTÁ FUNCIONANDO!');
      
    } else if (finalUrl.includes('/login') || finalUrl.includes('/auth')) {
      console.log('');
      console.log('❌ AINDA EM LOOP INFINITO');
      console.log('🔄 Voltou para a tela de login');
      
      // Verificar se há mensagem de erro
      const errorElement = await page.locator('text=Invalid, text=Error, .error').count();
      if (errorElement > 0) {
        const errorText = await page.locator('text=Invalid, text=Error, .error').first().textContent();
        console.log(`❌ Mensagem de erro: ${errorText}`);
      }
      
    } else {
      console.log(`❓ Estado indefinido - URL: ${finalUrl}`);
    }
    
  } else {
    console.log('❓ Não está na tela de login - pode já estar logado');
    console.log(`📍 URL atual: ${currentUrl}`);
  }
  
  console.log('');
  console.log('🏁 Teste concluído!');
});