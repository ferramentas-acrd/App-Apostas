import { test, expect } from '@playwright/test';

test('DEBUG AVANÇADO - Capturar Network e Console', async ({ page }) => {
  console.log('🔍 DEBUG AVANÇADO - MONITORAMENTO COMPLETO');
  console.log('=========================================');
  
  // Capturar todos os logs do console
  page.on('console', msg => {
    console.log(`🖥️ CONSOLE: ${msg.type()}: ${msg.text()}`);
  });
  
  // Capturar todas as requisições de rede
  page.on('request', request => {
    console.log(`📡 REQUEST: ${request.method()} ${request.url()}`);
  });
  
  // Capturar todas as respostas de rede
  page.on('response', response => {
    console.log(`📡 RESPONSE: ${response.status()} ${response.url()}`);
  });
  
  // Navegar para admin
  console.log('📍 Navegando para http://localhost:1338/admin');
  await page.goto('http://localhost:1338/admin');
  await page.waitForTimeout(5000);
  
  console.log(`🔗 URL inicial: ${page.url()}`);
  
  // Screenshot inicial
  await page.screenshot({ 
    path: 'tests/screenshots/debug-initial.png',
    fullPage: true 
  });
  
  // Verificar se há usuários existentes no banco SQLite
  const hasLogin = await page.locator('input[name="email"], input[name="password"]').count();
  const hasRegister = await page.locator('input[name="firstname"]').count();
  
  console.log(`📝 Campos - Login: ${hasLogin}, Register: ${hasRegister}`);
  
  if (hasRegister > 0) {
    console.log('✅ Tela de registro detectada - criando primeiro usuário');
    
    await page.fill('input[name="firstname"]', 'AdminApps');
    await page.fill('input[name="lastname"]', 'DeApostas');
    await page.fill('input[name="email"]', 'admin@appdeapostas.com.br');
    await page.fill('input[name="password"]', 'Admin123456!');
    
    const hasConfirm = await page.locator('input[name="confirmPassword"]').count();
    if (hasConfirm > 0) {
      await page.fill('input[name="confirmPassword"]', 'Admin123456!');
    }
    
    console.log('🔘 Submetendo formulário de registro...');
    await page.click('button[type="submit"]');
    
  } else if (hasLogin >= 2) {
    console.log('✅ Tela de login detectada - tentando login');
    
    // Tentar múltiplas credenciais
    const credentialsList = [
      { email: 'admin@appdeapostas.com.br', password: 'Admin123456!' },
      { email: 'admin@appdeapostas.com.br', password: 'AppsDeApostas2024!' },
      { email: 'caio.bessa@acroud.media', password: 'byMqat-hibdeh-9rycxy' }
    ];
    
    for (const creds of credentialsList) {
      console.log(`🔄 Tentando login: ${creds.email}`);
      
      await page.fill('input[name="email"]', creds.email);
      await page.fill('input[name="password"]', creds.password);
      
      console.log('🔘 Submetendo login...');
      await page.click('button[type="submit"]');
      await page.waitForTimeout(8000);
      
      const urlAfterLogin = page.url();
      console.log(`📍 URL após tentativa: ${urlAfterLogin}`);
      
      if (!urlAfterLogin.includes('/login') && !urlAfterLogin.includes('/auth')) {
        console.log(`✅ LOGIN BEM-SUCEDIDO com ${creds.email}!`);
        break;
      } else {
        console.log(`❌ Login falhou com ${creds.email}`);
        // Limpar campos para próxima tentativa
        await page.fill('input[name="email"]', '');
        await page.fill('input[name="password"]', '');
      }
    }
  }
  
  // Aguardar mais tempo para ver resultado final
  console.log('⏳ Aguardando resultado final...');
  await page.waitForTimeout(10000);
  
  const finalUrl = page.url();
  console.log(`🔗 URL FINAL: ${finalUrl}`);
  
  // Screenshot final
  await page.screenshot({ 
    path: 'tests/screenshots/debug-final.png',
    fullPage: true 
  });
  
  // Análise final
  if (!finalUrl.includes('/login') && !finalUrl.includes('/auth') && !finalUrl.includes('/register')) {
    console.log('');
    console.log('🎉🎉🎉 SUCESSO! DASHBOARD ACESSADO! 🎉🎉🎉');
    console.log('✅ Login funcionou perfeitamente!');
    console.log('✅ Dashboard do Strapi acessível!');
    console.log('✅ Problema do loop infinito RESOLVIDO!');
    
    // Verificar elementos do dashboard
    const title = await page.title();
    console.log(`📄 Título da página: ${title}`);
    
    // Aguardar elementos carregarem
    await page.waitForTimeout(3000);
    
    console.log('');
    console.log('🏆 MISSÃO CUMPRIDA - CMS 100% FUNCIONAL!');
    
  } else {
    console.log('');
    console.log('❌ Problema persiste - mais investigação necessária');
    console.log(`📍 Ainda em: ${finalUrl}`);
  }
  
  console.log('');
  console.log('🏁 Debug concluído!');
});